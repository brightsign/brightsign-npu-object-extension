#!/bin/sh
# Enhanced install script with pre-installation validation
set -e

# Enhanced pre-installation validation for Phase 3
validate_pre_install() {
    echo "🔍 Running enhanced pre-installation validation..."
    local validation_errors=0
    
    # Check if manifest.json exists in current directory
    if [ -f 'manifest.json' ]; then
        echo "📋 Found manifest.json, performing validation..."
        
        # Basic validation using jq if available
        if command -v jq >/dev/null 2>&1; then
            # Validate JSON syntax first
            if ! jq empty manifest.json 2>/dev/null; then
                echo "❌ Error: manifest.json contains invalid JSON syntax"
                validation_errors=$((validation_errors + 1))
            fi
            
            # Check manifest version
            local manifest_version=$(jq -r '.manifestVersion // 0' manifest.json 2>/dev/null)
            if [ "$manifest_version" != "1" ]; then
                echo "⚠️  Warning: Unknown manifest version: $manifest_version"
            fi
            
            # Enhanced OS compatibility checking
            local min_os=$(jq -r '.compatibility.osVersion.min // "0.0.0"' manifest.json 2>/dev/null)
            local max_os=$(jq -r '.compatibility.osVersion.max // null' manifest.json 2>/dev/null)
            if [ -f /etc/os-release ]; then
                local current_os=$(grep VERSION_ID /etc/os-release | cut -d= -f2 | tr -d '"')
                echo "📊 OS version: $current_os (minimum required: $min_os)"
                
                # Basic version comparison (simplified)
                if [ "$min_os" != "0.0.0" ]; then
                    echo "📋 Minimum OS version check: $current_os >= $min_os"
                fi
                if [ "$max_os" != "null" ] && [ -n "$max_os" ]; then
                    echo "📋 Maximum OS version declared: $max_os"
                fi
            fi
            
            # Enhanced storage requirements validation
            local install_storage=$(jq -r '.requirements.storage.installation // null' manifest.json 2>/dev/null)
            if [ "$install_storage" != "null" ] && [ -n "$install_storage" ]; then
                local available_space_kb=$(df /usr/local 2>/dev/null | tail -1 | awk '{print $4}')
                if [ -n "$available_space_kb" ]; then
                    local available_mb=$((available_space_kb / 1024))
                    echo "💾 Storage: ${available_mb}MB available (required: $install_storage)"
                    
                    # Parse required storage and check if sufficient
                    local required_num=$(echo "$install_storage" | sed 's/[^0-9]//g')
                    local required_unit=$(echo "$install_storage" | sed 's/[0-9]//g')
                    local required_mb="$required_num"
                    
                    case "$required_unit" in
                        GB) required_mb=$((required_num * 1024)) ;;
                        KB) required_mb=$((required_num / 1024)) ;;
                    esac
                    
                    if [ "$available_mb" -lt "$required_mb" ]; then
                        echo "❌ Error: Insufficient storage space (need ${required_mb}MB, have ${available_mb}MB)"
                        validation_errors=$((validation_errors + 1))
                    else
                        echo "✅ Storage requirement satisfied"
                    fi
                fi
            fi
            
            # Check hardware capabilities
            local capabilities=$(jq -r '.requirements.capabilities[]? // empty' manifest.json 2>/dev/null)
            if [ -n "$capabilities" ]; then
                echo "🔧 Checking hardware capabilities..."
                while IFS= read -r capability; do
                    case "$capability" in
                        "camera.usb")
                            if ls /dev/video* >/dev/null 2>&1; then
                                echo "✅ USB camera capability: Available"
                            else
                                echo "⚠️  Warning: No video devices found for camera.usb capability"
                            fi
                            ;;
                        "npu.rockchip")
                            if [ -f /sys/firmware/devicetree/base/compatible ] && strings /sys/firmware/devicetree/base/compatible | grep -q rockchip; then
                                echo "✅ NPU capability: Rockchip SoC detected"
                            else
                                echo "⚠️  Warning: Rockchip SoC not detected for npu.rockchip capability"
                            fi
                            ;;
                        *)
                            echo "ℹ️  Capability '$capability' - skipping validation"
                            ;;
                    esac
                done <<< "$capabilities"
            fi
            
            # Check for previous installation
            local ext_id=$(jq -r '.extension.id // "unknown"' manifest.json 2>/dev/null)
            if [ -b "/dev/mapper/bsos-ext_npu_yolo" ]; then
                echo "📦 Previous installation detected - will be replaced"
            fi
            
        else
            echo "ℹ️  jq not available, skipping detailed manifest validation"
        fi
    else
        echo "ℹ️  No manifest.json found, skipping pre-installation validation"
    fi
    
    # Final validation summary
    if [ "$validation_errors" -eq 0 ]; then
        echo "✅ Pre-installation validation passed ($validation_errors errors)"
        return 0
    else
        echo "❌ Pre-installation validation failed with $validation_errors errors"
        echo "🛑 Installation aborted due to validation failures"
        echo "💡 Please resolve the issues above and try again"
        return 1
    fi
    echo ""
}

# Run pre-installation validation and exit on failure
if ! validate_pre_install; then
    echo "❌ Installation aborted due to validation failures"
    exit 1
fi

# Proceed with installation
echo "🚀 Starting extension installation..."
echo "Trying to unmount npu_yolo volume"
if [ -d '/var/volatile/bsext/ext_npu_yolo' ]; then
    umount /var/volatile/bsext/ext_npu_yolo
    rmdir /var/volatile/bsext/ext_npu_yolo
fi
if [ -b '/dev/mapper/bsos-ext_npu_yolo-verified' ]; then
    veritysetup close 'bsos-ext_npu_yolo-verified'
fi
if [ -b '/dev/mapper/bsos-ext_npu_yolo' ]; then
    lvremove --yes '/dev/mapper/bsos-ext_npu_yolo'
    rm -f '/dev/mapper/bsos-ext_npu_yolo'
fi
if [ -b '/dev/mapper/bsos-tmp_npu_yolo' ]; then
    lvremove --yes '/dev/mapper/bsos-tmp_npu_yolo'
    rm -f '/dev/mapper/bsos-tmp_npu_yolo'
fi
lvcreate --yes --size 42184704b -n 'tmp_npu_yolo' bsos
echo Writing image to tmp_npu_yolo volume...
(cat ext_npu_yolo.squashfs && dd if=/dev/zero bs=4096 count=1) > /dev/mapper/bsos-tmp_npu_yolo
check="`dd 'if=/dev/mapper/bsos-tmp_npu_yolo' bs=4096 count=10298|sha256sum|cut -c-64`"
if [ "${check}" != "e951d5e5694ac6183540fdc8bf5db343409c640bd4d5b6be828b7818d8abd721" ]; then
    echo "VERIFY FAILURE for tmp_npu_yolo volume"
    lvremove --yes '/dev/mapper/bsos-tmp_npu_yolo' || true
    exit 4
fi
lvrename bsos 'tmp_npu_yolo' 'ext_npu_yolo'

echo "✅ Extension installation completed successfully!"
echo "📖 Run 'bsext_init --help' for usage information"
