#!/bin/sh
# This install script is only useful during development.
set -xe
echo "Trying to unmount npu_yolo volume"
if [ -d '/var/volatile/bsext/ext_npu_yolo' ]; then
    umount /var/volatile/bsext/ext_npu_yolo
    rmdir /var/volatile/bsext/ext_npu_yolo
fi
if [ -b '/dev/mapper/bsos-ext_npu_yolo-verified' ]; then
    veritysetup close 'bsos-ext_npu_yolo-verified'
fi
if [ -b '/dev/mapper/bsos-ext_npu_yolo' ]; then
    lvremove --yes '/dev/mapper/bsos-ext_npu_yolo'
    rm -f '/dev/mapper/bsos-ext_npu_yolo'
fi
if [ -b '/dev/mapper/bsos-tmp_npu_yolo' ]; then
    lvremove --yes '/dev/mapper/bsos-tmp_npu_yolo'
    rm -f '/dev/mapper/bsos-tmp_npu_yolo'
fi
lvcreate --yes --size 42180608b -n 'tmp_npu_yolo' bsos
echo Writing image to tmp_npu_yolo volume...
(cat ext_npu_yolo.squashfs && dd if=/dev/zero bs=4096 count=1) > /dev/mapper/bsos-tmp_npu_yolo
check="`dd 'if=/dev/mapper/bsos-tmp_npu_yolo' bs=4096 count=10297|sha256sum|cut -c-64`"
if [ "${check}" != "0e137d7d366443b486e16e317f9a53862003198336de514eb9f62499b6deb1c5" ]; then
    echo "VERIFY FAILURE for tmp_npu_yolo volume"
    lvremove --yes '/dev/mapper/bsos-tmp_npu_yolo' || true
    exit 4
fi
lvrename bsos 'tmp_npu_yolo' 'ext_npu_yolo'
